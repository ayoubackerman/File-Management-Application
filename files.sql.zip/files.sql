-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 17 mai 2021 à 11:16
-- Version du serveur :  10.4.18-MariaDB
-- Version de PHP : 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `files`
--

-- --------------------------------------------------------

--
-- Structure de la table `file`
--

CREATE TABLE `file` (
  `id_file` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `auteur` varchar(20) NOT NULL,
  `titre` varchar(20) NOT NULL,
  `resume` varchar(50) DEFAULT NULL,
  `commentaire` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `file`
--

INSERT INTO `file` (`id_file`, `id`, `url`, `auteur`, `titre`, `resume`, `commentaire`) VALUES
(7, 1, 'D:\\yow\\Battle.net.dll', 'Ali ta iji', 'Majechx', 'sds', 'sd'),
(11, 6, 'D:\\office-2016_16-0-7167-2060_fr_431791_32.exe', 'sd', 'sd', 'sd', 'sd'),
(12, 6, 'C:\\Users\\Dahmen\\Videos\\Captures\\Réunion _ Microsoft Teams 2020-11-04 09-53-23.mp4', 'sdx', 'sdx', 'sdx', 'sdx'),
(24, 1, 'C:\\Users\\Dahmen\\Documents\\Database1.accdb', 'sd', 'sd', 'sd', 'sd'),
(25, 1, 'C:\\Users\\Dahmen\\Documents\\Database1.accdb', 'sdss', 'sdss', 'sdss', 'sdss'),
(26, 1, 'C:\\Users\\Dahmen\\Documents\\Database1.accdb', 'sdssd', 'sdssd', 'sdssd', 'sdssd'),
(27, 6, 'C:\\Users\\Dahmen\\Desktop\\aio-runtimes_v2.5.0.exe', 'ddd', 'ddd', 'ddd', 'ddd'),
(28, 1, 'C:\\Users\\Dahmen\\Documents\\NetBeansProjects\\Projet java\\jfoenix-8.0.10.jar', 'Mark', 'How to make blabla', 'zzzzzz', 'blablabla'),
(29, 1, 'C:\\Users\\Dahmen\\Documents\\NetBeansProjects\\Projet java\\jfoenix-8.0.10.jar', 'Mark', 'How to make blabla', '', 'blablabla'),
(30, 1, 'C:\\Users\\Dahmen\\Documents\\NetBeansProjects\\Projet java\\jfoenix-8.0.10.jar', 'Mark', 'How to make blabla', '', 'blablabla'),
(33, 9, 'C:\\Users\\Dahmen\\Downloads\\installer-un-serveur-telnet.pdf', 'Hama', 'hama', 'hamma				', 'hamma'),
(34, 9, 'C:\\Users\\Dahmen\\Downloads\\installer-un-serveur-telnet.pdf', 'Hama', 'hama', 'hamma				', 'hamma'),
(35, 9, 'C:\\Users\\Dahmen\\Downloads\\installer-un-serveur-telnet.pdf', 'Hama', 'hama', 'hamma				', 'hamma'),
(36, 9, 'C:\\Users\\Dahmen\\Desktop\\prj\\presc.png', 'sd', 'sd', 'sds', 'd'),
(37, 9, 'C:\\Users\\Dahmen\\Desktop\\prj\\presc.png', 'sd', 'sd', 'sds', 'd'),
(38, 1, 'C:\\Users\\Dahmen\\Documents\\Database1.accdb', 'sd', 'sd', 'sd', 'sd'),
(39, 1, 'C:\\Users\\Dahmen\\Documents\\Database1.accdb', 'sd', 'sd', 'sd', 'sd'),
(40, 1, 'C:\\Users\\Dahmen\\Documents\\Database1.accdb', 'sd', 'sd', 'sd', 'sd'),
(42, 1, 'C:\\Users\\Dahmen\\Documents\\NetBeansProjects\\Projet java\\ProjetFx\\src\\CssStyle\\Style.css', 'sd', 'sd', 'sd', 'sd'),
(43, 1, 'C:\\Users\\Dahmen\\Documents\\NetBeansProjects\\Projet java\\jfoenix-8.0.10.jar', 'sd', 'sd', 'dddd', 'ddd'),
(44, 1, 'C:\\Users\\Dahmen\\Desktop\\5-Top-Technology-Trends-in-Transportation-and-Logistics-Industry.png', 'xsss', 'dddd', 'dddd', 'dddd'),
(46, 1, 'C:\\Users\\Dahmen\\Desktop\\client_server_xmpp.png', 'daa', 'daaa', 'daaa', 'daaa');

-- --------------------------------------------------------

--
-- Structure de la table `tags`
--

CREATE TABLE `tags` (
  `id_tag` int(11) NOT NULL,
  `id_file` int(11) NOT NULL,
  `tag` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tags`
--

INSERT INTO `tags` (`id_tag`, `id_file`, `tag`) VALUES
(4, 24, 'sd'),
(5, 25, 'sd'),
(6, 26, 'sds'),
(7, 27, 'sd'),
(8, 27, ''),
(9, 27, 'Security'),
(10, 27, 'Security'),
(11, 27, 'Security'),
(12, 27, 'Security'),
(13, 28, 'Security'),
(14, 29, 'Security'),
(15, 30, 'Security'),
(18, 33, ''),
(19, 34, 'Taggg'),
(20, 36, 'rr'),
(21, 37, 'rrrr'),
(22, 38, 'sd'),
(23, 39, 'sd'),
(24, 40, 'sd'),
(25, 40, 'rd'),
(26, 40, 'dr'),
(27, 40, 'dr'),
(36, 42, 'sd'),
(37, 42, 'complixty'),
(38, 42, 'Blabla'),
(39, 42, 'Hamhama'),
(40, 43, 'sdddd'),
(41, 43, 'dddd'),
(42, 43, 'dddd'),
(43, 44, 'dddd'),
(45, 46, 'daa'),
(46, 46, 'yess');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `Nomd` varchar(20) NOT NULL COMMENT 'Nom d''utilisateur',
  `mdp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `role`, `nom`, `prenom`, `mail`, `Nomd`, `mdp`) VALUES
(1, 'normal', 'Mustapha', 'Dahmen', 'abd@gmail.com', 'Dahmen12', 'mos99'),
(2, 'admin', 'mahdi', 'dahmen', 'mahdi@hotmail.com', 'Mahdiadm', 'ssd'),
(6, 'normal', 'hamma', 'mara', 'ssdfr', 'ha', 'ha'),
(8, 'normal', 'Muhammed', 'Amine', 'Amine@gmail.com', 'Amine12', 'amine'),
(9, 'normal', 'Hamma', 'Hamma', 'Hamma@gmail.com', 'Hamma12', 'hamma');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id_file`),
  ADD KEY `id` (`id`);

--
-- Index pour la table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id_tag`),
  ADD KEY `id_file` (`id_file`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `file`
--
ALTER TABLE `file`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT pour la table `tags`
--
ALTER TABLE `tags`
  MODIFY `id_tag` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `file`
--
ALTER TABLE `file`
  ADD CONSTRAINT `file_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `tags`
--
ALTER TABLE `tags`
  ADD CONSTRAINT `tags_ibfk_1` FOREIGN KEY (`id_file`) REFERENCES `file` (`id_file`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
